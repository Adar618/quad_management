package com.quadmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuadManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(QuadManagementApplication.class, args);
    }
}
