package com.quadmgmt.domain.model.enums;
public enum Role { OPERATOR, ADMIN }
