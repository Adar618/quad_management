
package com.quadmgmt;

import com.quadmgmt.domain.model.Booking;
import com.quadmgmt.domain.service.BookingService;
import com.quadmgmt.web.dto.BookingDto;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class BookingController {
    private final BookingService bookings;
    public BookingController(BookingService bookings) { this.bookings = bookings; }

    public record CreateBookingRequest(Long userId, int numberOfQuads,
                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {}

    public record Availability(boolean available) {}

    @GetMapping("/bookings/availability")
    public Availability check(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end,
            @RequestParam("numberOfQuads") int n) {
        return new Availability(bookings.isAvailable(n, start, end));
    }

    @PostMapping("/bookings")
    @ResponseStatus(HttpStatus.CREATED)
    public BookingDto create(@RequestBody CreateBookingRequest req) {
        Booking b = bookings.createBooking(req.userId(), req.numberOfQuads(), req.startTime(), req.endTime());
        return com.quadmgmt.web.mapper.ApiMapper.toDto(b);
    }

    @PostMapping("/bookings/{bookingId}:cancel")
    public BookingDto cancel(@PathVariable Long bookingId) {
        return bookings.cancelAndReturnDto(bookingId);
    }

    @GetMapping("/users/{userId}/bookings")
    public List<BookingDto> forUser(@PathVariable Long userId) {
        return bookings.listForUserAsDto(userId);
    }
}
