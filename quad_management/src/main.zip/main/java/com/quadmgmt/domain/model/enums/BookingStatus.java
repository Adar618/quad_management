package com.quadmgmt.domain.model.enums;
public enum BookingStatus { PENDING, CONFIRMED, COMPLETED, CANCELLED }
