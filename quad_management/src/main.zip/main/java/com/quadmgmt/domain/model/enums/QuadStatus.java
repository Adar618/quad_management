package com.quadmgmt.domain.model.enums;
public enum QuadStatus { AVAILABLE, BOOKED, MAINTENANCE }
