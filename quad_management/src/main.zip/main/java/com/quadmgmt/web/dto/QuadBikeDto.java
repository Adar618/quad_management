
package com.quadmgmt.web.dto;

public record QuadBikeDto(Long id, String registrationNumber, String model, String status) {}
