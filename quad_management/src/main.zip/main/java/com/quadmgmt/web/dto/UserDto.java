
package com.quadmgmt.web.dto;

public record UserDto(Long id, String username, String email, String role) {}
